##################################################
## GOBLET Antoine

from gridworld import GridWorld1
import gridrender as gui
import numpy as np
import time, pdb
import matplotlib.pyplot as plt

plt.rcParams.update({'text.usetex' : True,\
                     'font.size' : 17,\
                     'font.weight' : 'bold'})
env = GridWorld1

################################################################################
# Work to do: Q4
################################################################################
# here the v-function and q-function to be used for question 4
v_q4 = [0.87691855, 0.92820033, 0.98817903, 0.00000000, 0.67106071, -0.99447514, 0.00000000, -0.82847001, -0.87691855,
        -0.93358351, -0.99447514]
q_q4 = [[0.87691855, 0.65706417],
        [0.92820033, 0.84364237],
        [0.98817903, -0.75639924, 0.89361129],
        [0.00000000],
        [-0.62503460, 0.67106071],
        [-0.99447514, -0.70433689, 0.75620264],
        [0.00000000],
        [-0.82847001, 0.49505225],
        [-0.87691855, -0.79703229],
        [-0.93358351, -0.84424050, -0.93896668],
        [-0.89268904, -0.99447514]
        ]


# parameters
N = 11
gamma = 0.95
delta = 0.01
Tmax = - np.log( delta ) / (1 - gamma)
fps = 3
env.render = False
n = 10000

# initializations
states = range(N)
pol = [0,0,0,0,3,0,0,0,0,0,3]
#init_distribution = np.array([10.,20.,0.5,1.,1.,10.,1.,30.,1.,1.,1.])
init_distribution = np.ones(N)
init_distribution /= init_distribution.sum()
print("Initial state distribution : {}".format(init_distribution))
J = []
J_pi = sum( v_q4 ) / N
Q = []
normalized_Q = []
nb_of_visits = []
V = [0] * N
for state_init in range(N):
        Q.append([0] * len(env.state_actions[state_init]))
        normalized_Q.append([0] * len(env.state_actions[state_init]))
        nb_of_visits.append([0] * len(env.state_actions[state_init]))

for episode in range(n):
        t = 0
        #init_state = env.reset()
        init_state = np.random.choice(states,p=init_distribution)
        state = init_state
        action = np.random.choice(env.state_actions[state])
        idx = env.state_actions[init_state].index(action)
        nb_of_visits[init_state][idx] += 1

        for t in range(1,int(Tmax)):
                nexts, reward, term = env.step(state,action)
                state = nexts
                action = pol[state]
                Q[init_state][idx] += gamma ** (t-1) * reward
                if term:
                        break
                if env.render:
                        time.sleep(1./fps)
        
        normalized_Q[init_state][idx] = Q[init_state][idx] / nb_of_visits[init_state][idx]
        for state in range(N):
                action_pol = pol[state]
                idx = env.state_actions[state].index(action_pol)
                V[state] = normalized_Q[state][idx]

        J.append(sum(V) / N)

plt.figure()
plt.plot(np.array(J)-J_pi)
plt.xscale('linear')
plt.xlabel('Number of episodes')
plt.ylabel(r'$J_n - J^\pi$')
plt.title('Policy evaluation')
plt.show(block=False)

################################################################################
# Work to do: Q5
################################################################################
v_opt = [0.87691855, 0.92820033, 0.98817903, 0.00000000, 0.82369294, 0.92820033, 0.00000000, 0.77818504, 0.82369294,
         0.87691855, 0.82847001]

# parameters
gamma = 0.95
exploration_policy = 'e-greedy' # other choice : greedy_with_temperature_tau
epsilon = 0.01
delta = 0.01
Tmax = - np.log( delta ) / (1 - gamma)
fps = 3
n = 2000

# initalization
pol = np.zeros(N).astype(int)
V_hist = []
Q = []
nb_of_visits = []
alpha_hist = np.array([])
reward_hist = []
V = [0] * N
for state_init in range(N):
        Q.append([0] * len(env.state_actions[state_init]))
        nb_of_visits.append([0] * len(env.state_actions[state_init]))

##################################################
## computation of Q and V functions

for episode in range(n):
        #init_state = env.reset()
        init_state = np.random.choice(states,p=init_distribution)
        state = init_state
        action = np.random.choice(env.state_actions[state])
        cum_reward = 0

        for t in range(1,int(Tmax)):
                nexts, reward, term = env.step(state,action)
                cum_reward += reward
                
                idx = env.state_actions[state].index(action)

                nb_of_visits[state][idx] += 1
                cte = 50
                alpha = cte / (cte + nb_of_visits[state][idx])

                Q[state][idx] = (1-alpha)*Q[state][idx] + \
                                alpha*(reward+gamma*max(Q[nexts]))

                if exploration_policy == 'e-greedy':
                        if np.random.rand(1)[0] < 1-epsilon:
                                new_action = env.state_actions[nexts][np.argmax( Q[nexts] )]
                        else:
                                new_action = np.random.choice(env.state_actions[nexts])

                elif exploration_policy == 'greedy_with_temperature_tau':
                        prob = {}
                        tau = 1/t**3
                        for action in env.state_actions[nexts]:
                                idx_action = env.state_actions[nexts].index(action)
                                if idx_action == 0:
                                        new_action = action
                                prob[action] = np.exp(Q[nexts][idx_action] / tau) / \
                                               sum( np.exp(np.asarray(Q[nexts]) / tau) )
                                if prob[action] > prob[new_action]:
                                        new_action = action

                pol[nexts] = new_action
                state = nexts
                action = new_action

                if term:
                        break
                if env.render:
                        time.sleep(1./fps)

        reward_hist.append(cum_reward)
        for state in range(N):
                action_pol = pol[state]
                try:
                        idx = env.state_actions[state].index(action_pol)
                except:
                        continue
                V[state] = Q[state][idx]
        V_hist.append(np.array(V))

print("Optimal policy : {}".format(pol))
plt.figure()
plt.plot(np.max(np.abs(np.array(V_hist) - v_opt),axis=1))
plt.xscale('linear')
plt.xlabel('Number of episodes')
plt.ylabel(r'$\| V_n - V^* \| _\infty$')
plt.title('Policy optimization')
plt.show(block=False)

plt.figure()
plt.plot(reward_hist[:300],linestyle='None',marker='.')
plt.xscale('linear')
plt.xlabel('Index of episode')
plt.ylabel('Cumulated reward over the episode')
plt.title('Policy optimization')
plt.show()
